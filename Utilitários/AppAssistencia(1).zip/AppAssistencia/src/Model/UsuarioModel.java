package Model;

public class UsuarioModel extends LoginModel {

    //Atributos que definem o cadastro de um usuário
    private String id;
    private String userName;
    private String email;
    private String perfil;

    // Métodos Contrutores - vazio
    public UsuarioModel() {
    }

    //Contrutor utilizado para listagem de dados contidos no banco
    public UsuarioModel(String id, String userName, String email, String login, String password, String perfil) {
        super(login, password);
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.perfil = perfil;
    }

    //Construtor utilizado para inserir novo registro no banco de dados
    public UsuarioModel(String userName, String email, String login, String password, String perfil) {
        super(login, password);
        this.userName = userName;
        this.email = email;
        this.perfil = perfil;
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

}
