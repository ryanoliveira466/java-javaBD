package Testes;

import DAL.ConnectionFactory;

public class TestesGerais {

    public static void main(String[] args) {

        //Para acessar o método getConnection criado dentro
        //do pacote ConnectionFactory, é necessario instanciar
        //um objeto da classe ConnectionFactory na classe de 
        //de utilização da conexão. 
        ConnectionFactory conexao = new ConnectionFactory();
        conexao.getConnection();

    }

}
