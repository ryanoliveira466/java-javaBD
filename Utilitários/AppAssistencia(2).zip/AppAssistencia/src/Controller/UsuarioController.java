package Controller;

import Model.UsuarioModel;
import java.util.ArrayList;

public class UsuarioController {

    public ArrayList<UsuarioModel> listarRegistrosController() {
        UsuarioModel op = new UsuarioModel();
        return op.listarRegistrosModel();
    }

}
