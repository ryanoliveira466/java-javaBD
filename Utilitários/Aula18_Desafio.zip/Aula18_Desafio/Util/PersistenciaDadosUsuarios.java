package Aula18_Desafio.Util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class PersistenciaDadosUsuarios {

    String caminho = "C:\\Users\\Professor.SLEX25\\"
            + "Documents\\UC8_Programas\\ProgramasUC8\\dadosUsuarios.txt";

    ArrayList<Usuarios> cargaDadosCSV = new ArrayList<>();

    public void criarArquivoDados() {
        //Classe File, efetua a criação de arquivos externos
        File arquivo = new File(caminho);

        try {
            if (arquivo.createNewFile()) {
                System.out.println("Arquivo criado com sucesso!");
            } else {
                System.out.println("Arquivo já existente!");
            }

        } catch (Exception e) {
            System.out.println("\n ERRO AO CRIAR ARQUIVO!");
            System.out.println("\n REVISE O MÈTODO CRIAR ARQUIVO DADOS!");
        }
    }
    
    //Método de gravação de dados dentro do arquivo CSV;
    public void gravarDadosArquivoCSV(ArrayList<Usuarios> listaItens) {

        try {
            FileWriter escritor = new FileWriter(caminho);

            for (int i = 0; i < listaItens.size(); i++) {
                escritor.write(
                        listaItens.get(i).getNome()+ ","
                        + listaItens.get(i).getUsername()+ ","
                        + listaItens.get(i).getPassword()+ "\n");
            }
            escritor.close();
            System.out.println("Dados inseridos no arquivo com sucesso!");
        } catch (Exception e) {
            System.out.println("Erro ao escrever dados no arquivo txt");
            System.out.println("Revise o método de gravarDadosArquivoCSV");
            e.printStackTrace();
        }
    }
    
    //Método de leitura dos dados do arquivo CSV;
    public ArrayList<Usuarios> leituraDadosCSV() throws FileNotFoundException {

        File arquivo = new File(caminho);
        Scanner leitorArquivos = new Scanner(arquivo);

        try {
            while (leitorArquivos.hasNext()) {
                String linhaArquivo = leitorArquivos.nextLine();
                String vector[] = linhaArquivo.split(",");
                String nome = vector[0];
                String username = vector[1];
                String password = vector[2];
                Usuarios novoItem = new Usuarios(nome, username, password);
                cargaDadosCSV.add(novoItem);
            }
            leitorArquivos.close();
            System.out.println("Informações lidas com sucesso!");
            System.out.println("carga de dados realizada no arraylist!");

        } catch (Exception e) {
            System.out.println("Erro ao realizar a leitura do arquivo!");
            System.out.println("Verifique o método leituraDadosCSV");
            e.printStackTrace();
        }
        return cargaDadosCSV;
    }
    
}
