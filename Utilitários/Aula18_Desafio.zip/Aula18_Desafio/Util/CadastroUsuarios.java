package Aula18_Desafio.Util;

import Aula10_Desafio.PersistenciaDadosCSV;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CadastroUsuarios {

    //ArrayList para inserção de usuários em memoria de programa
    public class GlobalVars {

        public static ArrayList<Usuarios> bancoUsuarios = new ArrayList<Usuarios>();
    }

    PersistenciaDadosUsuarios operPersistencia = new PersistenciaDadosUsuarios();

    //Método que realize a inserção dos usuários no bancoUsuarios
    public void insereUsuarioBanco(Usuarios novoUsuario) {
        try {
            GlobalVars.bancoUsuarios.add(novoUsuario);
            String mensagem = "Usuario inserido com sucesso no banco!";
            JOptionPane.showMessageDialog(null, mensagem);
            operPersistencia.criarArquivoDados();
            operPersistencia.gravarDadosArquivoCSV(GlobalVars.bancoUsuarios);
            String mensagem2 = "Dados gravados no CSV com sucesso!";
            JOptionPane.showMessageDialog(null, mensagem2);
        } catch (Exception e) {
            String mensagem = "Erro ao inserir/gravar usuario! <CadastroUsuarios/InsereUsuarioBanco>";
            JOptionPane.showMessageDialog(null, mensagem);
            e.printStackTrace();
        }
    }

    //Método que busca usuários no arrayList
    public boolean buscaUsario(String name, String password) {
        boolean contem;
        Integer indexNome = 0;
        Integer indexSenha = 0;

        for (int i = 0; i < GlobalVars.bancoUsuarios.size(); i++) {

            if (name.equals(GlobalVars.bancoUsuarios.get(i).getUsername())) {
                indexNome = i;
            }

            if (password.equals(GlobalVars.bancoUsuarios.get(i).getPassword())) {
                indexSenha = i;
                System.out.println(indexSenha);
            }
        }

        //Verificação do valor do index de posição de usuario e senha
        //if (indexNome.equals(indexSenha) && GlobalVars.bancoUsuarios.size() != 0) {
        System.out.println("Tamanho Array: " + GlobalVars.bancoUsuarios.size());
        System.out.println("Index Nome: " + indexNome);
        System.out.println("Index Senha: " + indexSenha);
        
        
        if (indexNome.equals(indexSenha)) {
            contem = true;
        } else {
            contem = false;
        }
        return contem;
    }

    public void populaArrayBancoUsuarios() throws FileNotFoundException {

        try {
            GlobalVars.bancoUsuarios = operPersistencia.leituraDadosCSV();

            System.out.println(GlobalVars.bancoUsuarios.size());

            String mensagem = "Dados lidos do arquivo CSV com suscesso!";
            System.out.println(mensagem);
        } catch (Exception e) {
            String mensagem = "Erro ao ler dados do CSV! <popularArrayBancoUsuarios>";
            JOptionPane.showMessageDialog(null, mensagem);

        }
    }

}
